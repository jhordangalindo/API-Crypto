"""
=============================================================================
DTOs (DATA TRANSFER OBJECTS) - MODELOS DE DATOS
=============================================================================

Este módulo contiene los DTOs (Data Transfer Objects) utilizados para
estructurar los datos de respuesta de la API de criptomonedas.

¿Qué es un DTO?
---------------
Un DTO es un objeto que define la estructura de los datos que se transfieren
entre capas de la aplicación o hacia/desde clientes externos.

¿Por qué usar DTOs en FastAPI?
------------------------------
1. VALIDACIÓN AUTOMÁTICA: Pydantic valida que los datos cumplan el esquema
2. DOCUMENTACIÓN: FastAPI genera docs automáticos (Swagger) basados en los DTOs
3. SERIALIZACIÓN: Convierte automáticamente objetos Python a JSON
4. TYPE HINTS: Mejora el autocompletado y detección de errores en el IDE
5. CONSISTENCIA: Garantiza que todas las respuestas tengan el mismo formato

Ejemplo de respuesta generada:
{
    "coin": "bitcoin",
    "price_usd": 43000.25,
    "market_cap_usd": 840000000000,
    "change_24h_percent": 2.45
}

Autor: Jordan Galindo
Fecha: Enero 2026
=============================================================================
"""

from pydantic import BaseModel, Field


class CryptoResponseDTO(BaseModel):
    """
    DTO para la respuesta de criptomonedas.

    Este modelo define la estructura exacta de los datos que se devuelven
    cuando un usuario consulta información de una criptomoneda.

    Atributos:
        coin (str): Identificador de la criptomoneda
        price_usd (float): Precio actual en dólares estadounidenses
        market_cap_usd (float): Capitalización de mercado en USD
        change_24h_percent (float): Variación porcentual en las últimas 24 horas
    """

    # =========================================================================
    # CAMPO: coin (identificador de la criptomoneda)
    # =========================================================================
    coin: str = Field(
        ...,
        description="Identificador de la criptomoneda consultada",
        examples=["bitcoin", "ethereum", "solana"]
    )

    # =========================================================================
    # CAMPO: price_usd (precio en USD)
    # =========================================================================
    price_usd: float = Field(
        ...,
        description="Precio actual de la criptomoneda en USD",
        examples=[43000.25, 2500.75, 98.32]
    )

    # =========================================================================
    # CAMPO: market_cap_usd (capitalización de mercado)
    # =========================================================================
    market_cap_usd: float = Field(
        ...,
        description="Capitalización de mercado de la criptomoneda en USD",
        examples=[840000000000, 300000000000, 42000000000]
    )

    # =========================================================================
    # CAMPO: change_24h_percent (variación 24 horas)
    # =========================================================================
    change_24h_percent: float = Field(
        ...,
        description="Variación porcentual del precio en las últimas 24 horas",
        examples=[2.45, -1.32, 5.78]
    )

    # =========================================================================
    # CONFIGURACIÓN DEL MODELO
    # =========================================================================
    class Config:
        """
        Configuración adicional del modelo Pydantic.
        """
        json_schema_extra = {
            "example": {
                "coin": "bitcoin",
                "price_usd": 43000.25,
                "market_cap_usd": 840000000000,
                "change_24h_percent": 2.45
            }
        }
