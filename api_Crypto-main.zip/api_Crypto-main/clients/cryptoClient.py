"""
=============================================================================
CLIENTE HTTP PARA LA API DE COINGECKO
=============================================================================

Este módulo contiene la clase CoinGeckoClient, encargada de gestionar
toda la comunicación con la API externa de CoinGecko.

En una arquitectura de capas (Layered Architecture), este cliente se
encarga exclusivamente de:
- Realizar peticiones HTTP a servicios externos
- Manejar errores de comunicación
- Devolver datos crudos al Service Layer

Este cliente NO contiene lógica de negocio.

API utilizada:
https://api.coingecko.com/en/api/documentation

Autor: Jordan Galindo
Fecha: Enero 2026
=============================================================================
"""

# Librería para realizar peticiones HTTP asíncronas
import httpx

# Para lanzar errores HTTP controlados por FastAPI
from fastapi import HTTPException


class CoinGeckoClient:
    """
    Cliente HTTP para interactuar con la API de CoinGecko.

    Aplica el patrón "Client Layer", permitiendo:
    - Separar la lógica HTTP de la lógica de negocio
    - Centralizar el manejo de errores externos
    - Facilitar pruebas unitarias y mocks
    """

    # ------------------------------------------------------------------
    # URL BASE DE LA API
    # ------------------------------------------------------------------
    BASE_URL = "https://api.coingecko.com/api/v3"

    async def get_crypto_data(
        self,
        coin: str,
        http_client: httpx.AsyncClient
    ) -> dict:
        """
        Obtiene información de una criptomoneda desde CoinGecko.

        Flujo del método:
        1. Realiza la petición HTTP a la API externa
        2. Valida el estado de la respuesta
        3. Devuelve los datos crudos para ser procesados por el Service Layer

        Args:
            coin (str): ID de la criptomoneda en CoinGecko.
                        Ejemplos válidos:
                        - bitcoin
                        - ethereum
                        - solana

            http_client (httpx.AsyncClient): Cliente HTTP asíncrono compartido,
                        inyectado desde el controlador.

        Returns:
            dict: Respuesta cruda de CoinGecko.

            Estructura típica:
            {
                "bitcoin": {
                    "usd": 43000,
                    "usd_market_cap": 840000000000,
                    "usd_24h_change": 2.5
                }
            }

        Raises:
            HTTPException(404): Si la criptomoneda no existe
            HTTPException(503): Si no se puede conectar con CoinGecko
            HTTPException(500): Si ocurre un error inesperado
        """

        # ===============================================================
        # PASO 1: REALIZAR PETICIÓN HTTP A COINGECKO
        # ===============================================================
        try:
            response = await http_client.get(
                f"{self.BASE_URL}/simple/price",
                params={
                    "ids": coin,
                    "vs_currencies": "usd",
                    "include_market_cap": "true",
                    "include_24hr_change": "true"
                },
                timeout=10
            )

        except httpx.RequestError:
            # Error de red, timeout o problema de conexión
            raise HTTPException(
                status_code=503,
                detail="No fue posible conectar con la API de CoinGecko"
            )

        # ===============================================================
        # PASO 2: VALIDAR RESPUESTA HTTP
        # ===============================================================
        if response.status_code != 200:
            raise HTTPException(
                status_code=500,
                detail="Error interno al consultar la API de CoinGecko"
            )

        data = response.json()

        # ===============================================================
        # PASO 3: VALIDAR CONTENIDO DE LA RESPUESTA
        # ===============================================================
        # CoinGecko devuelve {} cuando el ID no existe
        if not data or coin not in data:
            raise HTTPException(
                status_code=404,
                detail=f"La criptomoneda '{coin}' no fue encontrada en CoinGecko"
            )

        return data
