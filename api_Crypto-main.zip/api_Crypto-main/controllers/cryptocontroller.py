import httpx
from fastapi import APIRouter, HTTPException

from services.cryptoservices import CryptoService
from DTOs.cryptoDtos import CryptoResponseDTO

# -------------------------------------------------------------------------
# CONFIGURACIÓN DEL ROUTER
# -------------------------------------------------------------------------
router = APIRouter(
    prefix="/api",
    tags=["Crypto"]
)

# -------------------------------------------------------------------------
# ENDPOINT: CONSULTAR UNA CRIPTOMONEDA
# -------------------------------------------------------------------------
@router.get(
    "/crypto/{coin}",
    response_model=CryptoResponseDTO
)
async def get_crypto(coin: str):
    """
    Obtiene información de una criptomoneda desde la API de CoinGecko.

    Ejemplos válidos:
        /api/crypto/bitcoin
        /api/crypto/ethereum
        /api/crypto/solana

    ⚠️ Importante:
    CoinGecko NO acepta símbolos como BTC o ETH.
    """

    # Cliente HTTP asíncrono (reutilizable y eficiente)
    async with httpx.AsyncClient() as http_client:

        # Instancia del servicio (lógica de negocio)
        crypto_service = CryptoService()

        try:
            # Llamada al servicio
            crypto_response = await crypto_service.get_crypto(
                coin=coin,
                http_client=http_client
            )

            return crypto_response

        # -------------------------------------------------------------
        # ERRORES CONTROLADOS (404, 400, etc.)
        # -------------------------------------------------------------
        except HTTPException as e:
            raise e

        # -------------------------------------------------------------
        # ERRORES INESPERADOS
        # -------------------------------------------------------------
        except Exception as e:
            print(f"ERROR INTERNO: {e}")  # útil para debug en consola

            raise HTTPException(
                status_code=500,
                detail="Error interno al consultar la criptomoneda"
            )
