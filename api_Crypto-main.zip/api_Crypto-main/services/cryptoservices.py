"""
=============================================================================
SERVICIO DE CRIPTOMONEDAS (CAPA DE LÓGICA DE NEGOCIO)
=============================================================================

Este servicio contiene la lógica de negocio para consultar información
de criptomonedas usando la API pública de CoinGecko.

Responsabilidades:
1. Validar la entrada del usuario
2. Normalizar IDs de criptomonedas
3. Coordinar la comunicación con el cliente HTTP
4. Transformar la respuesta en un DTO limpio
5. Manejar errores de forma controlada

Autor: Jordan Galindo
Fecha: Enero 2026
=============================================================================
"""

import httpx
from fastapi import HTTPException

from clients.cryptoClient import CoinGeckoClient
from DTOs.cryptoDtos import CryptoResponseDTO


class CryptoService:
    """
    Servicio principal para obtener información de criptomonedas
    usando la API pública de CoinGecko.
    """

    # ------------------------------------------------------------------
    # MAPEO DE SÍMBOLOS A IDS DE COINGECKO
    # CoinGecko NO acepta BTC, ETH, etc.
    # ------------------------------------------------------------------
    SYMBOL_MAP = {
        "btc": "bitcoin",
        "eth": "ethereum",
        "sol": "solana",
        "bnb": "binancecoin",
        "ada": "cardano",
        "xrp": "ripple",
        "dot": "polkadot",
        "doge": "dogecoin"
    }

    def __init__(self):
        # CoinGecko no requiere API Key
        self.client = CoinGeckoClient()

    async def get_crypto(
        self,
        coin: str,
        http_client: httpx.AsyncClient
    ) -> CryptoResponseDTO:
        """
        Obtiene información de una criptomoneda y la devuelve en formato DTO.

        Args:
            coin (str): ID o símbolo de la criptomoneda
                        Ej: bitcoin, ethereum, btc, eth
            http_client (httpx.AsyncClient): Cliente HTTP asíncrono

        Returns:
            CryptoResponseDTO
        """

        # ===============================================================
        # PASO 1: VALIDAR Y NORMALIZAR ENTRADA
        # ===============================================================
        coin = coin.strip().lower()

        if not coin:
            raise HTTPException(
                status_code=400,
                detail="El identificador de la criptomoneda no puede estar vacío"
            )

        # Convertir símbolo a ID real de CoinGecko si existe
        coin_id = self.SYMBOL_MAP.get(coin, coin)

        # ===============================================================
        # PASO 2: CONSULTAR COINGECKO
        # ===============================================================
        try:
            crypto_data = await self.client.get_crypto_data(
                coin=coin_id,
                http_client=http_client
            )
        except httpx.HTTPError:
            raise HTTPException(
                status_code=500,
                detail="Error de comunicación con la API de CoinGecko"
            )

        if not crypto_data or coin_id not in crypto_data:
            raise HTTPException(
                status_code=404,
                detail=f"La criptomoneda '{coin}' no existe en CoinGecko"
            )

        data = crypto_data[coin_id]

        # ===============================================================
        # PASO 3: MAPEAR RESPUESTA A DTO
        # ===============================================================
        return CryptoResponseDTO(
            coin=coin_id,
            price_usd=data.get("usd"),
            market_cap_usd=data.get("usd_market_cap"),
            change_24h_percent=data.get("usd_24h_change")
        )
